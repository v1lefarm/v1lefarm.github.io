import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Category from "./pages/Category";
import OrderHistory from "./pages/OrderHistory";
import Profile from "./pages/Profile";
import UserProfile from "./pages/UserProfile";
import Admin from "./pages/Admin";
import SetupUsername from "./pages/SetupUsername";
import { useAuth } from "./_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import StartupVideo from "./components/StartupVideo";

function RequireUsername({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, loading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && isAuthenticated && user && !user.username && location !== "/setup-username") {
      setLocation("/setup-username");
    }
  }, [user, isAuthenticated, loading, location, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return <>{children}</>;
}

function Router() {
  return (
    <RequireUsername>
      <Switch>
        <Route path="/setup-username" component={SetupUsername} />
        <Route path={"/"} component={Home} />
        <Route path="/category" component={Category} />
        <Route path="/orders" component={OrderHistory} />
        <Route path="/profile" component={Profile} />
        <Route path="/user/:username" component={UserProfile} />
        <Route path="/admin" component={Admin} />
        <Route path={"/404"} component={NotFound} />
        {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
    </RequireUsername>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  const [showStartup, setShowStartup] = useState(() => {
    // Check if startup video has been shown in this session
    return !sessionStorage.getItem("startupVideoShown");
  });

  const handleStartupComplete = () => {
    sessionStorage.setItem("startupVideoShown", "true");
    setShowStartup(false);
  };

  if (showStartup) {
    return <StartupVideo onComplete={handleStartupComplete} />;
  }

  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
