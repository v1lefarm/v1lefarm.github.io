import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { APP_LOGO } from "@/const";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { useEffect } from "react";
import { toast } from "sonner";
import { CheckCircle, XCircle, Trash2, Users, Search } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [showUsers, setShowUsers] = useState(false);
  const [userSearch, setUserSearch] = useState("");
  const { data: orders, isLoading, refetch } = trpc.orders.allOrders.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const { data: users, refetch: refetchUsers } = trpc.admin.getAllUsers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const { data: revenueData, refetch: refetchRevenue } = trpc.admin.getRevenue.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const updateStatusMutation = trpc.orders.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Order status updated!");
      refetch();
      refetchRevenue();
    },
    onError: (error) => {
      toast.error(`Failed to update order: ${error.message}`);
    },
  });

  const resetRevenueMutation = trpc.admin.resetRevenue.useMutation({
    onSuccess: () => {
      toast.success("Revenue reset successfully!");
      refetchRevenue();
    },
    onError: (error) => {
      toast.error(`Failed to reset revenue: ${error.message}`);
    },
  });

  const deleteAllOrdersMutation = trpc.admin.deleteAllOrders.useMutation({
    onSuccess: () => {
      toast.success("All orders deleted!");
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to delete orders: ${error.message}`);
    },
  });

  const deleteOrderMutation = trpc.orders.delete.useMutation({
    onSuccess: () => {
      toast.success("Order deleted!");
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to delete order: ${error.message}`);
    },
  });

  const updateUserRoleMutation = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => {
      toast.success("User role updated!");
      refetchUsers();
    },
    onError: (error) => {
      toast.error(`Failed to update role: ${error.message}`);
    },
  });

  useEffect(() => {
    if (!isAuthenticated || user?.role !== "admin") {
      setLocation("/");
    }
  }, [isAuthenticated, user, setLocation]);

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You need admin privileges to access this page</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/20 text-yellow-500 border-yellow-500/30";
      case "approved":
        return "bg-green-500/20 text-green-500 border-green-500/30";
      case "rejected":
        return "bg-red-500/20 text-red-500 border-red-500/30";
      case "completed":
        return "bg-blue-500/20 text-blue-500 border-blue-500/30";
      case "cancelled":
        return "bg-gray-500/20 text-gray-500 border-gray-500/30";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const pendingOrders = orders?.filter(o => o.status === "pending") || [];
  const approvedOrders = orders?.filter(o => o.status === "approved") || [];
  const totalRevenue = revenueData?.totalRevenue || 0;

  const filteredUsers = useMemo(() => {
    if (!users) return [];
    if (!userSearch.trim()) return users;
    const searchLower = userSearch.toLowerCase();
    return users.filter(u => 
      (u.username?.toLowerCase().includes(searchLower)) ||
      (u.name?.toLowerCase().includes(searchLower)) ||
      (u.email?.toLowerCase().includes(searchLower))
    );
  }, [users, userSearch]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                <img src={APP_LOGO} alt="V1LE Farm" className="h-8 w-8 sm:h-10 sm:w-10 invert" />
                <span className="text-lg sm:text-xl font-bold">V1LE Farm</span>
              </div>
            </Link>
            <nav className="flex items-center gap-2 sm:gap-4">
              <Link href="/category">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Shop</Button>
              </Link>
              <Link href="/orders">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Orders</Button>
              </Link>
              <Link href="/admin">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Admin</Button>
              </Link>
              <Link href="/profile">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Profile</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
        <h2 className="text-3xl sm:text-4xl font-bold mb-6 sm:mb-8 text-foreground">Admin Panel</h2>

        {/* Statistics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg">Pending Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-yellow-500">{pendingOrders.length}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg">Approved Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-500">{approvedOrders.length}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Total Revenue</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    if (confirm("Are you sure you want to reset the revenue counter? This cannot be undone!")) {
                      resetRevenueMutation.mutate();
                    }
                  }}
                  disabled={resetRevenueMutation.isPending}
                  className="text-xs"
                >
                  Reset
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-primary">${totalRevenue}</p>
              {revenueData?.lastReset && (
                <p className="text-xs text-muted-foreground mt-2">
                  Last reset: {new Date(revenueData.lastReset).toLocaleDateString()}
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <Button
            variant="outline"
            onClick={() => setShowUsers(!showUsers)}
            className="flex items-center gap-2"
          >
            <Users className="w-4 h-4" />
            {showUsers ? "Show Orders" : "Manage Users"}
          </Button>
          {!showUsers && orders && orders.length > 0 && (
            <Button
              variant="destructive"
              onClick={() => {
                if (confirm("Are you sure you want to delete ALL orders? This cannot be undone!")) {
                  deleteAllOrdersMutation.mutate();
                }
              }}
              disabled={deleteAllOrdersMutation.isPending}
              className="flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Delete All Orders
            </Button>
          )}
        </div>

        {/* User Management */}
        {showUsers ? (
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Manage user roles and permissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search by username, name, or email..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              {filteredUsers && filteredUsers.length > 0 ? (
                <div className="space-y-4">
                  {filteredUsers.map((u) => (
                    <Card key={u.id} className="bg-background border-border">
                      <CardContent className="pt-6">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="flex-1">
                            <p className="font-semibold text-lg">{u.name || "Unknown User"}</p>
                            <p className="text-sm text-muted-foreground">{u.email || "No email"}</p>
                            <p className="text-xs text-muted-foreground mt-1">ID: {u.id}</p>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge className={u.role === "admin" ? "bg-red-500/20 text-red-500" : "bg-blue-500/20 text-blue-500"}>
                              {u.role?.toUpperCase() || "USER"}
                            </Badge>
                            <Select
                              value={u.role || "user"}
                              onValueChange={(newRole: "admin" | "user") => {
                                if (u.id === user?.id) {
                                  toast.error("You cannot change your own role!");
                                  return;
                                }
                                updateUserRoleMutation.mutate({ userId: u.id, role: newRole });
                              }}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="user">User</SelectItem>
                                <SelectItem value="admin">Admin</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : userSearch.trim() ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No users found matching "{userSearch}"</p>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No users found</p>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          /* Orders List */
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>All Orders</CardTitle>
              <CardDescription>Manage customer orders</CardDescription>
            </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Loading orders...</p>
              </div>
            ) : orders && orders.length > 0 ? (
              <div className="space-y-4">
                {orders.map((order) => (
                  <Card key={order.id} className="bg-background border-border">
                    <CardHeader>
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        <div className="flex-1">
                          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                            Order #{order.id}
                            <Badge className={getStatusColor(order.status)}>
                              {order.status.toUpperCase()}
                            </Badge>
                          </CardTitle>
                          <CardDescription className="text-xs sm:text-sm">
                            {order.createdAt ? new Date(order.createdAt).toLocaleString() : "N/A"}
                          </CardDescription>
                        </div>
                        <div className="text-left sm:text-right">
                          <p className="text-xl sm:text-2xl font-bold text-primary">
                            ${order.totalPrice}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Customer</p>
                          <p className="font-medium">{order.customerName}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Telegram</p>
                          <p className="font-medium">@{order.telegramUsername}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Product</p>
                          <p className="font-medium">{order.productName}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Quantity</p>
                          <p className="font-medium">{order.quantity}g</p>
                        </div>
                      </div>
                      <div className="flex gap-2 pt-4 border-t border-border">
                        {order.status === "pending" && (
                          <>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() =>
                                updateStatusMutation.mutate({
                                  orderId: order.id,
                                  status: "approved",
                                })
                              }
                              disabled={updateStatusMutation.isPending}
                              className="flex-1"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Approve
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() =>
                                updateStatusMutation.mutate({
                                  orderId: order.id,
                                  status: "rejected",
                                })
                              }
                              disabled={updateStatusMutation.isPending}
                              className="flex-1"
                            >
                              <XCircle className="w-4 h-4 mr-2" />
                              Reject
                            </Button>
                          </>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete order #${order.id}?`)) {
                              deleteOrderMutation.mutate({ orderId: order.id });
                            }
                          }}
                          disabled={deleteOrderMutation.isPending}
                          className="flex items-center gap-2"
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-xl font-semibold mb-2">No orders yet</p>
                <p className="text-muted-foreground">Orders will appear here when customers place them</p>
              </div>
            )}
          </CardContent>
        </Card>
        )}
      </main>
    </div>
  );
}

