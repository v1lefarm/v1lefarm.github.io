import { useAuth } from "@/_core/hooks/useAuth";
import { Trash2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { useEffect } from "react";

export default function OrderHistory() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: orders, isLoading, refetch: refetchOrders } = trpc.orders.myOrders.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const cancelOrderMutation = trpc.orders.cancel.useMutation({
    onSuccess: () => {
      toast.success("Order cancelled successfully!");
      refetchOrders();
    },
    onError: (error) => {
      toast.error(`Failed to cancel order: ${error.message}`);
    },
  });

  const deleteOrderMutation = trpc.orders.delete.useMutation({
    onSuccess: () => {
      toast.success("Order deleted successfully!");
      refetchOrders();
    },
    onError: (error) => {
      toast.error(`Failed to delete order: ${error.message}`);
    },
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>Please log in to view your orders</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <a href={getLoginUrl()}>Login with Telegram</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/20 text-yellow-500 border-yellow-500/30";
      case "approved":
        return "bg-green-500/20 text-green-500 border-green-500/30";
      case "rejected":
        return "bg-red-500/20 text-red-500 border-red-500/30";
      case "completed":
        return "bg-blue-500/20 text-blue-500 border-blue-500/30";
      case "cancelled":
        return "bg-gray-500/20 text-gray-500 border-gray-500/30";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer">
              <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
              <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-2 sm:gap-4">
            <Link href="/category">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Shop</Button>
            </Link>
            <Link href="/orders">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Orders</Button>
            </Link>
            {user?.role === "admin" && (
              <Link href="/admin">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Admin</Button>
              </Link>
            )}
            <Link href="/profile">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Profile</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground">Order History</h2>
            <Link href="/category">
              <Button size="sm" className="text-xs sm:text-sm">New Order</Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Loading orders...</p>
            </div>
          ) : orders && orders.length > 0 ? (
            <div className="space-y-4">
              {orders.map((order) => (
                <Card key={order.id} className="bg-card border-border">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          Order #{order.id}
                          <Badge className={getStatusColor(order.status)}>
                            {order.status.toUpperCase()}
                          </Badge>
                        </CardTitle>
                        <CardDescription>
                          {order.createdAt ? new Date(order.createdAt).toLocaleString() : "N/A"}
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">
                          ${order.totalPrice}
                        </p>
                        <p className="text-xs text-muted-foreground">Cash on delivery</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Product</p>
                        <p className="font-medium">{order.productName}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Quantity</p>
                        <p className="font-medium">{order.quantity}g</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Price per gram</p>
                        <p className="font-medium">${order.pricePerGram}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Telegram</p>
                        <p className="font-medium">@{order.telegramUsername}</p>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-4 border-t border-border">
                      {order.status === "pending" && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => cancelOrderMutation.mutate({ orderId: order.id })}
                          disabled={cancelOrderMutation.isPending}
                        >
                          <XCircle className="w-4 h-4 mr-2" />
                          Cancel Order
                        </Button>
                      )}
                      {(order.status === "rejected" || order.status === "cancelled" || order.status === "completed") && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteOrderMutation.mutate({ orderId: order.id })}
                          disabled={deleteOrderMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-card border-border">
              <CardContent className="py-12 text-center">
                <img 
                  src="/logo.v1le.png" 
                  alt="No orders" 
                  className="h-24 w-auto mx-auto invert opacity-50 mb-4"
                />
                <p className="text-xl font-semibold mb-2">No orders yet</p>
                <p className="text-muted-foreground mb-6">
                  Start by placing your first order
                </p>
                <Link href="/category">
                  <Button>Browse Products</Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      <footer className="border-t border-border py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 V1LE Farm. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

