import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { Star } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

export default function Category() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(2);
  const [customQuantity, setCustomQuantity] = useState("");
  const [useCustom, setUseCustom] = useState(false);
  
  const presetQuantities = [2, 2.5, 5, 10];
  
  const [rating, setRating] = useState(0);
  const [reviewComment, setReviewComment] = useState("");
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  const { data: reviews, refetch: refetchReviews } = trpc.reviews.getByProduct.useQuery(
    { productName: "God Complex" },
    { enabled: isAuthenticated }
  );
  
  const { data: userReview, refetch: refetchUserReview } = trpc.reviews.getUserReview.useQuery(
    { productName: "God Complex" },
    { enabled: isAuthenticated }
  );
  
  useEffect(() => {
    if (userReview) {
      setRating(userReview.rating);
      setReviewComment(userReview.comment || "");
      setIsEditing(true);
    }
  }, [userReview]);
  
  const averageRating = reviews && reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : "0.0";
  
  const createReviewMutation = trpc.reviews.create.useMutation({
    onSuccess: () => {
      toast.success("Review posted successfully!");
      setShowReviewForm(false);
      refetchReviews();
      refetchUserReview();
    },
    onError: (error) => {
      toast.error(`Failed to post review: ${error.message}`);
    },
  });
  
  const updateReviewMutation = trpc.reviews.update.useMutation({
    onSuccess: () => {
      toast.success("Review updated successfully!");
      setShowReviewForm(false);
      refetchReviews();
      refetchUserReview();
    },
    onError: (error) => {
      toast.error(`Failed to update review: ${error.message}`);
    },
  });
  
  const handleSubmitReview = () => {
    if (rating === 0) {
      toast.error("Please select a rating");
      return;
    }
    
    if (isEditing) {
      updateReviewMutation.mutate({
        productName: "God Complex",
        rating,
        comment: reviewComment.trim() || undefined,
      });
    } else {
      createReviewMutation.mutate({
        productName: "God Complex",
        rating,
        comment: reviewComment.trim() || undefined,
      });
    }
  };
  const [telegramUsername, setTelegramUsername] = useState("");
  const { data: profile } = trpc.profile.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (profile?.telegramUsername) {
      setTelegramUsername(profile.telegramUsername);
    }
  }, [profile]);
  const pricePerGram = 10;

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      toast.success("Order placed successfully! We'll contact you on Telegram.");
      setQuantity(1);
      setTelegramUsername("");
      setTimeout(() => setLocation("/orders"), 1500);
    },
    onError: (error) => {
      toast.error(`Failed to place order: ${error.message}`);
    },
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>Please log in to place an order</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button asChild>
              <a href={getLoginUrl()}>Login with Telegram</a>
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  const handleOrder = () => {
    const username = telegramUsername.trim().replace("@", "");
    
    if (!username) {
      toast.error("Please add your Telegram username in your profile first");
      setTimeout(() => setLocation("/profile"), 1500);
      return;
    }

    if (quantity < 2) {
      toast.error("Minimum order is 2g");
      return;
    }

    createOrderMutation.mutate({
      telegramUsername: username,
      productName: "God Complex",
      quantity,
      pricePerGram,
    });
  };

  const totalPrice = quantity * pricePerGram;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer">
              <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
              <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-2 sm:gap-4">
            <Link href="/category">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Shop</Button>
            </Link>
            <Link href="/orders">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Orders</Button>
            </Link>
            {user?.role === "admin" && (
              <Link href="/admin">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Admin</Button>
              </Link>
            )}
            <Link href="/profile">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Profile</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 sm:mb-8 text-foreground">Our Products</h2>

          <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
            <Card className="bg-card border-border">
              <CardHeader>
                <div className="mb-4">
                  <img src="/god-complex.png" alt="God Complex" className="w-full h-48 object-contain mb-4" />
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-2xl">God Complex</CardTitle>
                      <CardDescription className="text-lg">${pricePerGram}/gram</CardDescription>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star className="w-5 h-5 fill-current" />
                      <span className="text-lg font-semibold">{averageRating}</span>
                      <span className="text-sm text-muted-foreground">({reviews?.length || 0})</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Premium strain with exceptional quality. Perfect balance of potency and flavor.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Hand-selected premium quality</li>
                  <li>✓ Lab tested for purity</li>
                  <li>✓ Minimum order: 0.5g</li>
                  <li>✓ Cash payment on delivery</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle>Place Your Order</CardTitle>
                <CardDescription>Fill in the details below</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="telegram">Telegram Username *</Label>
                  <div className="relative">
                    <Input
                      id="telegram"
                      placeholder="Set in profile"
                      value={telegramUsername ? `@${telegramUsername}` : ""}
                      readOnly
                      className="mt-1 bg-muted cursor-not-allowed"
                    />
                    <Link href="/profile">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-1 top-1.5 h-7 text-xs"
                        type="button"
                      >
                        Edit
                      </Button>
                    </Link>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {telegramUsername 
                      ? "We'll contact you here to confirm your order"
                      : "Please set your Telegram username in your profile"}
                  </p>
                </div>

                <div>
                  <Label>Quantity (grams)</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {presetQuantities.map((preset) => (
                      <Button
                        key={preset}
                        type="button"
                        variant={!useCustom && quantity === preset ? "default" : "outline"}
                        onClick={() => {
                          setUseCustom(false);
                          setQuantity(preset);
                        }}
                        className="h-12"
                      >
                        {preset}g
                      </Button>
                    ))}
                  </div>
                  <div className="mt-3">
                    <Button
                      type="button"
                      variant={useCustom ? "default" : "outline"}
                      onClick={() => setUseCustom(!useCustom)}
                      className="w-full"
                    >
                      Custom Amount
                    </Button>
                  </div>
                  {useCustom && (
                    <div className="mt-2">
                      <Input
                        type="number"
                        min="2"
                        step="0.5"
                        placeholder="Enter amount (min 2g)"
                        value={customQuantity}
                        onChange={(e) => {
                          const val = e.target.value;
                          setCustomQuantity(val);
                          const num = parseFloat(val);
                          if (num >= 2) {
                            setQuantity(num);
                          }
                        }}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Minimum 2g (cannot select 1.5g or below)
                      </p>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Total:</span>
                    <span className="text-primary">${totalPrice.toFixed(2)}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Pay in cash when you receive your order
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={handleOrder}
                  disabled={createOrderMutation.isPending}
                >
                  {createOrderMutation.isPending ? "Placing Order..." : "Place Order"}
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Reviews Section */}
          <div className="max-w-4xl mx-auto mt-12">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl sm:text-3xl font-bold text-foreground">Reviews</h3>
              {isAuthenticated && (
                <Button
                  variant={showReviewForm ? "outline" : "default"}
                  onClick={() => setShowReviewForm(!showReviewForm)}
                >
                  {showReviewForm ? "Cancel" : (isEditing ? "Edit Review" : "Write Review")}
                </Button>
              )}
            </div>

            {showReviewForm && (
              <Card className="bg-card border-border mb-6">
                <CardHeader>
                  <CardTitle>Write a Review</CardTitle>
                  <CardDescription>Share your experience with God Complex</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Rating</Label>
                    <div className="flex gap-2 mt-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="focus:outline-none"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              star <= rating
                                ? "fill-primary text-primary"
                                : "text-muted-foreground"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="review">Comment (optional)</Label>
                    <Textarea
                      id="review"
                      placeholder="Tell us what you think..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      rows={4}
                      className="mt-1"
                    />
                  </div>
                  <Button
                    onClick={handleSubmitReview}
                    disabled={createReviewMutation.isPending || updateReviewMutation.isPending}
                    className="w-full"
                  >
                    {(createReviewMutation.isPending || updateReviewMutation.isPending)
                      ? (isEditing ? "Updating..." : "Posting...")
                      : (isEditing ? "Update Review" : "Post Review")}
                  </Button>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {reviews && reviews.length > 0 ? (
                reviews.map((review) => (
                  <Card key={review.id} className="bg-card border-border">
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <Link href={review.user?.username ? `/user/${review.user.username}` : "#"}>
                          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center cursor-pointer hover:bg-primary/30 transition-colors overflow-hidden">
                            {review.user?.profilePicture ? (
                              <img
                                src={review.user.profilePicture}
                                alt={review.user.username || review.user.name || "User"}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <span className="text-lg font-bold text-primary">
                                {review.user?.username?.[0]?.toUpperCase() ||
                                  review.user?.name?.[0]?.toUpperCase() ||
                                  "?"}
                              </span>
                            )}
                          </div>
                        </Link>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Link href={review.user?.username ? `/user/${review.user.username}` : "#"}>
                              <h4 className="font-semibold hover:text-primary cursor-pointer">
                                {review.user?.username
                                  ? `@${review.user.username}`
                                  : review.user?.name || "Anonymous"}
                              </h4>
                            </Link>
                            <span className="text-xs text-muted-foreground">
                              {review.createdAt
                                ? new Date(review.createdAt).toLocaleDateString()
                                : ""}
                            </span>
                          </div>
                          <div className="flex gap-1 mb-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${
                                  star <= review.rating
                                    ? "fill-primary text-primary"
                                    : "text-muted-foreground"
                                }`}
                              />
                            ))}
                          </div>
                          {review.comment && (
                            <p className="text-sm text-foreground">{review.comment}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="bg-card border-border">
                  <CardContent className="py-12 text-center">
                    <p className="text-muted-foreground">No reviews yet. Be the first to review!</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-border py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 V1LE Farm. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

