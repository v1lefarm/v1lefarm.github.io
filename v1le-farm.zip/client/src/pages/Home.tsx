import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
            <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
          </div>
          <nav className="flex items-center gap-2 sm:gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/category">
                  <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Shop</Button>
                </Link>
                <Link href="/orders">
                  <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Orders</Button>
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Admin</Button>
                  </Link>
                )}
                <Link href="/profile">
                  <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Profile</Button>
                </Link>
              </>
            ) : (
              <Button asChild size="sm" className="text-xs sm:text-sm">
                <a href={getLoginUrl()}>Login</a>
              </Button>
            )}
          </nav>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-4 py-8 sm:py-0">
        <div className="max-w-4xl w-full text-center space-y-6 sm:space-y-8">
          <img 
            src="/logo.v1le.png" 
            alt="V1LE Farm Logo" 
            className="h-32 sm:h-48 w-auto mx-auto invert opacity-90"
          />
          
          <h2 className="text-3xl sm:text-5xl font-bold text-foreground">
            Welcome to V1LE Farm
          </h2>
          
          <p className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
            Premium cannabis delivered with care. Browse our selection and place your order today.
          </p>

          <div className="flex gap-4 justify-center pt-4 sm:pt-8">
            {isAuthenticated ? (
              <Link href="/category">
                <Button size="lg" className="text-base sm:text-lg px-6 sm:px-8">
                  Browse Products
                </Button>
              </Link>
            ) : (
              <Button size="lg" className="text-base sm:text-lg px-6 sm:px-8" asChild>
                <a href={getLoginUrl()}>Get Started</a>
              </Button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 pt-8 sm:pt-12">
            <div className="p-4 sm:p-6 rounded-lg bg-card border border-border">
              <h3 className="text-lg sm:text-xl font-semibold mb-2 text-card-foreground">Premium Quality</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                Hand-selected strains for the best experience
              </p>
            </div>
            <div className="p-4 sm:p-6 rounded-lg bg-card border border-border">
              <h3 className="text-lg sm:text-xl font-semibold mb-2 text-card-foreground">Easy Ordering</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                Simple checkout with Telegram authentication
              </p>
            </div>
            <div className="p-4 sm:p-6 rounded-lg bg-card border border-border">
              <h3 className="text-lg sm:text-xl font-semibold mb-2 text-card-foreground">Cash Payment</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                Pay in cash when you receive your order
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-border py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 V1LE Farm. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

