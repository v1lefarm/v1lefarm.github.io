import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link, useLocation, useRoute } from "wouter";

export default function UserProfile() {
  const [, params] = useRoute("/user/:username");
  const username = params?.username || "";
  
  const { data: user, isLoading } = trpc.profile.getByUsername.useQuery(
    { username },
    { enabled: !!username }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="border-b border-border">
          <div className="container mx-auto px-4 py-3 sm:py-4">
            <Link href="/">
              <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
              </div>
            </Link>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading profile...</p>
          </div>
        </main>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="border-b border-border">
          <div className="container mx-auto px-4 py-3 sm:py-4">
            <Link href="/">
              <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
              </div>
            </Link>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="py-12 text-center">
              <h2 className="text-2xl font-bold mb-2">User Not Found</h2>
              <p className="text-muted-foreground mb-6">
                The user @{username} does not exist.
              </p>
              <Link href="/category">
                <Button>Back to Shop</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
              <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
              <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
            </div>
          </Link>
          <Link href="/category">
            <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Back to Shop</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-card border-border">
            <CardHeader className="text-center">
              <div className="flex flex-col items-center gap-4">
                <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
                  {user.profilePicture ? (
                    <img
                      src={user.profilePicture}
                      alt={user.username || user.name || "User"}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-4xl font-bold text-primary">
                      {user.username?.[0]?.toUpperCase() || user.name?.[0]?.toUpperCase() || "?"}
                    </span>
                  )}
                </div>
                <div>
                  <CardTitle className="text-2xl sm:text-3xl">
                    {user.name || "Anonymous User"}
                  </CardTitle>
                  {user.username && (
                    <CardDescription className="text-lg mt-1">
                      @{user.username}
                    </CardDescription>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {user.bio && (
                <div>
                  <h3 className="text-sm font-semibold text-muted-foreground mb-2">Bio</h3>
                  <p className="text-foreground">{user.bio}</p>
                </div>
              )}

              <div className="pt-4 border-t border-border">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Member Since</p>
                    <p className="font-medium">
                      {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Role</p>
                    <p className="font-medium capitalize">{user.role || "user"}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="border-t border-border py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 V1LE Farm. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

