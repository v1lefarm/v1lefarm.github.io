import { useEffect, useRef, useState } from "react";
import { Button } from "./ui/button";
import { X } from "lucide-react";

interface StartupVideoProps {
  onComplete: () => void;
}

export default function StartupVideo({ onComplete }: StartupVideoProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isSkippable, setIsSkippable] = useState(false);

  useEffect(() => {
    // Allow skipping after 2 seconds
    const timer = setTimeout(() => {
      setIsSkippable(true);
    }, 2000);

    // Auto-complete when video ends
    const video = videoRef.current;
    if (video) {
      video.play().catch((error) => {
        console.error("Video autoplay failed:", error);
        // If autoplay fails, allow immediate skip
        setIsSkippable(true);
      });

      const handleEnded = () => {
        onComplete();
      };

      video.addEventListener("ended", handleEnded);

      return () => {
        clearTimeout(timer);
        video.removeEventListener("ended", handleEnded);
      };
    }

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[9999] bg-black flex items-center justify-center">
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        playsInline
        muted
        preload="auto"
      >
        <source src="/startup.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {isSkippable && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white"
          onClick={onComplete}
        >
          <X className="w-6 h-6" />
        </Button>
      )}
    </div>
  );
}

