# V1LE Farm - Setup Guide

## Overview

V1LE Farm is a cannabis ordering web application with Telegram authentication and bot notifications. Customers can browse products, place orders, and track their order history. Admins receive instant Telegram notifications with approve/reject buttons.

## Features

✅ **Telegram Authentication** - Secure login via Manus OAuth with Telegram  
✅ **Product Ordering** - God Complex strain at $10/gram (minimum 0.5g)  
✅ **Order Management** - Track order status and history  
✅ **Telegram Notifications** - Instant alerts to admin and group chat  
✅ **Interactive Buttons** - Approve/reject orders directly from Telegram  
✅ **Dark Theme** - Black and red color palette with V1LE branding  

## Pages

1. **Home** (`/`) - Landing page with branding and navigation
2. **Category** (`/category`) - Product catalog and order placement
3. **Order History** (`/orders`) - View all past orders with status

## Telegram Bot Setup

### Bot Configuration

The Telegram bot is already configured with:
- **Bot Token**: `7815244310:AAH_Pr-8qbKysycnnznahrAQ4zZOfva0XUg`
- **Admin Chat ID**: `6665237815` (your personal notifications)
- **Group Chat ID**: `-4959546169` (group notifications)

### Webhook Status

The webhook is active at:
```
https://3000-i4lx60p5qzqo9cf53uio0-6b0a1cbc.manus.computer/api/webhook/telegram
```

When an order is placed, the bot sends notifications to both your personal chat and the group with:
- Customer name and Telegram username
- Product details and quantity
- Total price
- ✅ Approve and ❌ Reject buttons

### How It Works

1. Customer logs in with Telegram via Manus OAuth
2. Customer places order with their Telegram username
3. Order is saved to database with "pending" status
4. Bot sends notification to admin chat and group
5. Admin clicks Approve or Reject button
6. Order status updates in database
7. Confirmation message sent back to Telegram

## Database Schema

### Users Table
- `id` - User ID (from OAuth)
- `name` - Display name
- `email` - Email address
- `telegramUsername` - Telegram handle
- `role` - "user" or "admin"
- `createdAt` - Account creation timestamp
- `lastSignedIn` - Last login timestamp

### Orders Table
- `id` - Auto-increment order ID
- `userId` - Customer user ID
- `customerName` - Customer display name
- `telegramUsername` - Customer Telegram handle
- `productName` - Product name (God Complex)
- `quantity` - Quantity in grams
- `pricePerGram` - Price per gram ($10)
- `totalPrice` - Total order price
- `status` - "pending", "approved", "rejected", or "completed"
- `createdAt` - Order placement timestamp
- `updatedAt` - Last status update timestamp

## Environment Variables

All secrets are pre-configured:
- `TELEGRAM_BOT_TOKEN` - Bot API token
- `TELEGRAM_ADMIN_CHAT_ID` - Your personal chat ID
- `TELEGRAM_GROUP_CHAT_ID` - Group chat ID
- `DATABASE_URL` - MySQL database connection
- `JWT_SECRET` - Session signing secret
- OAuth credentials (auto-injected)

## Testing the App

### 1. Access the Website
Visit: https://3000-i4lx60p5qzqo9cf53uio0-6b0a1cbc.manus.computer

### 2. Login
Click "Login with Telegram" to authenticate

### 3. Place an Order
1. Navigate to "Shop" or click "Browse Products"
2. Enter your Telegram username (e.g., @v1leshop)
3. Select quantity (minimum 0.5g, increments of 0.5g)
4. Review total price
5. Click "Place Order"

### 4. Receive Notification
Check your Telegram for:
- Personal message to chat ID `6665237815`
- Group message to chat ID `-4959546169`
- Both with Approve/Reject buttons

### 5. Approve/Reject Order
Click the button in Telegram to update order status

### 6. View Order History
Navigate to "Order History" to see all orders with status badges

## Color Palette (Black & Red Theme)

- **Background**: Deep black (`oklch(0.1 0 0)`)
- **Foreground**: Off-white (`oklch(0.95 0 0)`)
- **Primary/Accent**: Red (`oklch(0.55 0.22 25)`)
- **Cards**: Dark gray (`oklch(0.15 0 0)`)
- **Borders**: Medium gray (`oklch(0.3 0 0)`)

## API Endpoints

### tRPC Procedures

**Public:**
- `auth.me` - Get current user
- `auth.logout` - Logout user

**Protected:**
- `orders.create` - Create new order
- `orders.myOrders` - Get user's orders
- `orders.allOrders` - Get all orders (admin only)
- `orders.updateStatus` - Update order status (admin only)

**Webhook:**
- `POST /api/webhook/telegram` - Telegram bot callback handler

## Deployment Notes

The app is currently running in development mode. When ready to deploy:

1. The webhook URL will need to be updated to your production domain
2. Run `./setup-telegram-webhook.sh` with the new URL
3. Ensure all environment variables are set in production
4. Database migrations are already applied

## Support

For issues or questions, contact the development team or check the Telegram group.

---

**© 2025 V1LE Farm. All rights reserved.**

