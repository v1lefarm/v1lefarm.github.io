CREATE TABLE `revenue` (
	`id` int AUTO_INCREMENT NOT NULL,
	`totalRevenue` int NOT NULL DEFAULT 0,
	`lastReset` timestamp DEFAULT (now()),
	`updatedAt` timestamp DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `revenue_id` PRIMARY KEY(`id`)
);
