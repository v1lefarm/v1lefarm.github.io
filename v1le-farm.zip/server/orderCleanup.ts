import { getDb } from "./db";
import { orders } from "../drizzle/schema";
import { and, eq, lt, sql } from "drizzle-orm";

/**
 * Delete approved orders older than 5 days
 */
export async function cleanupOldApprovedOrders(): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[OrderCleanup] Cannot cleanup orders: database not available");
    return 0;
  }

  try {
    // Calculate the date 5 days ago
    const fiveDaysAgo = new Date();
    fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);

    // Delete approved and rejected orders older than 5 days
    await db
      .delete(orders)
      .where(
        and(
          sql`${orders.status} IN ('approved', 'rejected')`,
          lt(orders.updatedAt, fiveDaysAgo)
        )
      );

    console.log(`[OrderCleanup] Cleaned up approved and rejected orders older than 5 days`);

    return 0;
  } catch (error) {
    console.error("[OrderCleanup] Failed to cleanup old orders:", error);
    return 0;
  }
}

/**
 * Start the cleanup service that runs every hour
 */
export function startOrderCleanupService(): NodeJS.Timeout {
  // Run cleanup immediately on startup
  cleanupOldApprovedOrders();

  // Then run every hour
  const interval = setInterval(() => {
    cleanupOldApprovedOrders();
  }, 60 * 60 * 1000); // 1 hour in milliseconds

  console.log("[OrderCleanup] Cleanup service started (runs every hour)");

  return interval;
}

