import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, User, users, orders, InsertOrder, Order, reviews, InsertReview, Review, revenue, Revenue } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.id) {
    throw new Error("User ID is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      id: user.id,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role === undefined) {
      if (user.id === ENV.ownerId) {
        user.role = 'admin';
        values.role = 'admin';
        updateSet.role = 'admin';
      }
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function updateUserProfile(userId: string, updates: { name?: string; bio?: string; telegramUsername?: string; username?: string; profilePicture?: string }): Promise<User | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update user profile: database not available");
    return null;
  }

  try {
    await db.update(users).set(updates).where(eq(users.id, userId));
    const updated = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    return updated.length > 0 ? updated[0] : null;
  } catch (error) {
    console.error("[Database] Failed to update user profile:", error);
    throw error;
  }
}

export async function getUser(id: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createOrder(order: InsertOrder): Promise<Order | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create order: database not available");
    return null;
  }

  try {
    const result = await db.insert(orders).values(order);
    const insertId = Number(result[0].insertId);
    
    const created = await db.select().from(orders).where(eq(orders.id, insertId)).limit(1);
    return created.length > 0 ? created[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create order:", error);
    throw error;
  }
}

export async function getUserOrders(userId: string): Promise<Order[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user orders: database not available");
    return [];
  }

  try {
    return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get user orders:", error);
    return [];
  }
}

export async function getAllOrders(): Promise<Order[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get all orders: database not available");
    return [];
  }

  try {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get all orders:", error);
    return [];
  }
}

export async function updateOrderStatus(orderId: number, status: string): Promise<Order | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update order: database not available");
    return null;
  }

  try {
    // Get order before updating to check previous status
    const orderBefore = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    const previousStatus = orderBefore.length > 0 ? orderBefore[0].status : null;
    
    await db.update(orders).set({ status: status as any }).where(eq(orders.id, orderId));
    const updated = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    
    // Add to revenue when order is approved for the first time
    if (status === "approved" && previousStatus !== "approved" && updated.length > 0) {
      await addRevenue(updated[0].totalPrice);
    }
    
    return updated.length > 0 ? updated[0] : null;
  } catch (error) {
    console.error("[Database] Failed to update order status:", error);
    throw error;
  }
}

export async function getOrderById(orderId: number): Promise<Order | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get order: database not available");
    return null;
  }

  try {
    const result = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get order:", error);
    return null;
  }
}

export async function createReview(review: InsertReview): Promise<Review | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create review: database not available");
    return null;
  }

  try {
    const result = await db.insert(reviews).values(review);
    const insertId = Number(result[0].insertId);
    
    const created = await db.select().from(reviews).where(eq(reviews.id, insertId)).limit(1);
    return created.length > 0 ? created[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create review:", error);
    throw error;
  }
}

export async function cancelOrder(orderId: number, userId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot cancel order: database not available");
    return false;
  }

  try {
    // Verify the order belongs to the user and is pending
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    
    if (!order || order.userId !== userId) {
      throw new Error("Order not found or unauthorized");
    }

    if (order.status !== "pending") {
      throw new Error("Can only cancel pending orders");
    }

    await db.update(orders).set({ status: "cancelled" }).where(eq(orders.id, orderId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to cancel order:", error);
    throw error;
  }
}

export async function deleteOrder(orderId: number, userId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete order: database not available");
    return false;
  }

  try {
    // Verify the order belongs to the user
    const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    
    if (!order || order.userId !== userId) {
      throw new Error("Order not found or unauthorized");
    }

    await db.delete(orders).where(eq(orders.id, orderId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete order:", error);
    throw error;
  }
}

export async function getProductReviews(productName: string): Promise<Array<Review & { user: User | null }>> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get product reviews: database not available");
    return [];
  }

  try {
    const reviewList = await db.select().from(reviews).where(eq(reviews.productName, productName)).orderBy(desc(reviews.createdAt));
    
    const reviewsWithUsers = await Promise.all(
      reviewList.map(async (review) => {
        const user = await getUser(review.userId);
        return { ...review, user: user || null };
      })
    );
    
    return reviewsWithUsers;
  } catch (error) {
    console.error("[Database] Failed to get product reviews:", error);
    return [];
  }
}


export async function deleteAllOrders(): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete all orders: database not available");
    return false;
  }

  try {
    await db.delete(orders);
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete all orders:", error);
    return false;
  }
}

export async function getAllUsers(): Promise<User[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get users: database not available");
    return [];
  }

  try {
    const allUsers = await db.select().from(users);
    return allUsers;
  } catch (error) {
    console.error("[Database] Failed to get users:", error);
    return [];
  }
}

export async function updateUserRole(userId: string, role: "admin" | "user"): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update user role: database not available");
    return false;
  }

  try {
    await db.update(users).set({ role }).where(eq(users.id, userId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to update user role:", error);
    return false;
  }
}



export async function getUserReview(userId: string, productName: string): Promise<Review | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user review: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(reviews)
      .where(and(eq(reviews.userId, userId), eq(reviews.productName, productName)))
      .limit(1);
    
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get user review:", error);
    return null;
  }
}

export async function updateReview(review: { userId: string; productName: string; rating: number; comment?: string }): Promise<Review> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db
      .update(reviews)
      .set({
        rating: review.rating,
        comment: review.comment,
        updatedAt: new Date(),
      })
      .where(and(eq(reviews.userId, review.userId), eq(reviews.productName, review.productName)));
    
    const updated = await getUserReview(review.userId, review.productName);
    if (!updated) {
      throw new Error("Failed to retrieve updated review");
    }
    
    return updated;
  } catch (error) {
    console.error("[Database] Failed to update review:", error);
    throw error;
  }
}



export async function getRevenue(): Promise<Revenue> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const result = await db.select().from(revenue).limit(1);
    
    if (result.length === 0) {
      // Initialize revenue tracking if it doesn't exist
      await db.insert(revenue).values({ totalRevenue: 0 });
      return { id: 1, totalRevenue: 0, lastReset: new Date(), updatedAt: new Date() };
    }
    
    return result[0];
  } catch (error) {
    console.error("[Database] Failed to get revenue:", error);
    throw error;
  }
}

export async function addRevenue(amount: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const current = await getRevenue();
    await db
      .update(revenue)
      .set({
        totalRevenue: current.totalRevenue + amount,
        updatedAt: new Date(),
      })
      .where(eq(revenue.id, current.id));
  } catch (error) {
    console.error("[Database] Failed to add revenue:", error);
    throw error;
  }
}

export async function resetRevenue(): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const current = await getRevenue();
    await db
      .update(revenue)
      .set({
        totalRevenue: 0,
        lastReset: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(revenue.id, current.id));
  } catch (error) {
    console.error("[Database] Failed to reset revenue:", error);
    throw error;
  }
}

