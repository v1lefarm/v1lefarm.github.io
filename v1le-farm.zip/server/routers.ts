import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createOrder, getUserOrders, getAllOrders, updateOrderStatus as dbUpdateOrderStatus, getOrderById, updateUserProfile, getUser, createReview, getProductReviews, cancelOrder, deleteOrder, deleteAllOrders, getAllUsers, updateUserRole, getUserReview, updateReview, getRevenue, resetRevenue } from "./db";
import { uploadProfilePicture } from "./profilePicture";
import { notifyNewOrder, notifyOrderStatusUpdate, notifyOrderCancelled, notifyOrderDeleted } from "./telegram";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  orders: router({
    create: protectedProcedure
      .input(
        z.object({
          telegramUsername: z.string().min(1),
          productName: z.string(),
          quantity: z.number().positive(),
          pricePerGram: z.number().positive(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const totalPrice = input.quantity * input.pricePerGram;
        
        const order = await createOrder({
          userId: ctx.user.id,
          customerName: ctx.user.name || "Unknown",
          telegramUsername: input.telegramUsername,
          productName: input.productName,
          quantity: input.quantity,
          pricePerGram: input.pricePerGram,
          totalPrice,
          status: "pending",
        });

        if (order) {
          await notifyNewOrder(order);
        }

        return order;
      }),

    myOrders: protectedProcedure.query(async ({ ctx }) => {
      return await getUserOrders(ctx.user.id);
    }),

    allOrders: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized");
      }
      return await getAllOrders();
    }),

    cancel: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Get order details before cancelling
        const order = await getOrderById(input.orderId);
        const success = await cancelOrder(input.orderId, ctx.user.id);
        if (success && order) {
          // Notify about cancellation
          await notifyOrderCancelled(order);
        }
        return { success };
      }),

    delete: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Get order details before deleting
        const order = await getOrderById(input.orderId);
        const success = await deleteOrder(input.orderId, ctx.user.id);
        if (success && order) {
          // Notify about deletion
          await notifyOrderDeleted(order);
        }
        return { success };
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          orderId: z.number(),
          status: z.enum(["pending", "approved", "rejected", "completed"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }

        const order = await dbUpdateOrderStatus(input.orderId, input.status);
        
        if (order) {
          await notifyOrderStatusUpdate(order, input.status);
        }

        return order;
      }),
  }),

  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return await getUser(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          name: z.string().optional(),
          bio: z.string().optional(),
          telegramUsername: z.string().optional(),
          username: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await updateUserProfile(ctx.user.id, input);
      }),

    uploadProfilePicture: protectedProcedure
      .input(z.object({ base64Image: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const imageUrl = await uploadProfilePicture(input.base64Image, ctx.user.id);
        await updateUserProfile(ctx.user.id, { profilePicture: imageUrl });
        return { url: imageUrl };
      }),

    getByUsername: publicProcedure
      .input(z.object({ username: z.string() }))
      .query(async ({ input }) => {
        const db = await import("./db").then(m => m.getDb());
        if (!db) return null;
        const result = await db.select().from(await import("../drizzle/schema").then(m => m.users)).where(
          (await import("drizzle-orm").then(m => m.eq))(
            (await import("../drizzle/schema").then(m => m.users)).username,
            input.username
          )
        ).limit(1);
        return result.length > 0 ? result[0] : null;
      }),
  }),

  admin: router({
    deleteAllOrders: protectedProcedure.mutation(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      const success = await deleteAllOrders();
      return { success };
    }),

    getAllUsers: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      return await getAllUsers();
    }),

    updateUserRole: protectedProcedure
      .input(
        z.object({
          userId: z.string(),
          role: z.enum(["admin", "user"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const success = await updateUserRole(input.userId, input.role);
        return { success };
      }),

    getRevenue: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      return await getRevenue();
    }),

    resetRevenue: protectedProcedure.mutation(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      await resetRevenue();
      return { success: true };
    }),
  }),

  reviews: router({
    create: protectedProcedure
      .input(
        z.object({
          productName: z.string(),
          rating: z.number().min(1).max(5),
          comment: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createReview({
          userId: ctx.user.id,
          productName: input.productName,
          rating: input.rating,
          comment: input.comment,
        });
      }),

    getByProduct: publicProcedure
      .input(z.object({ productName: z.string() }))
      .query(async ({ input }) => {
        return await getProductReviews(input.productName);
      }),

    getUserReview: protectedProcedure
      .input(z.object({ productName: z.string() }))
      .query(async ({ ctx, input }) => {
        return await getUserReview(ctx.user.id, input.productName);
      }),

    update: protectedProcedure
      .input(
        z.object({
          productName: z.string(),
          rating: z.number().min(1).max(5),
          comment: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await updateReview({
          userId: ctx.user.id,
          productName: input.productName,
          rating: input.rating,
          comment: input.comment,
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
