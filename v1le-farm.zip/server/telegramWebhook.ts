import { Router } from "express";
import { updateOrderStatus, getOrderById } from "./db";
import { notifyOrderStatusUpdate } from "./telegram";

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

export const telegramWebhookRouter = Router();

telegramWebhookRouter.post("/webhook/telegram", async (req, res) => {
  try {
    const update = req.body;

    // Handle callback queries (button presses)
    if (update.callback_query) {
      const callbackData = update.callback_query.data;
      const chatId = update.callback_query.message.chat.id;
      const messageId = update.callback_query.message.message_id;

      // Parse callback data (format: "approve_123" or "reject_123")
      const [action, orderIdStr] = callbackData.split("_");
      const orderId = parseInt(orderIdStr, 10);

      if (!orderId || isNaN(orderId)) {
        return res.status(400).json({ error: "Invalid order ID" });
      }

      // Update order status
      let newStatus: string;
      if (action === "approve") {
        newStatus = "approved";
      } else if (action === "reject") {
        newStatus = "rejected";
      } else {
        return res.status(400).json({ error: "Invalid action" });
      }

      const order = await updateOrderStatus(orderId, newStatus);

      if (order) {
        // Send confirmation message
        await fetch(
          `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerCallbackQuery`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              callback_query_id: update.callback_query.id,
              text: `Order #${orderId} ${newStatus}!`,
            }),
          }
        );

        // Get admin name from callback query
        const adminName = update.callback_query.from.first_name || "Admin";
        const adminUsername = update.callback_query.from.username ? `@${update.callback_query.from.username}` : adminName;
        
        // Edit the original message to show updated status with admin action
        const statusEmoji = newStatus === "approved" ? "✅" : "❌";
        const actionText = newStatus === "approved" ? "APPROVED" : "REJECTED";
        
        await fetch(
          `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/editMessageText`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              chat_id: chatId,
              message_id: messageId,
              text: `${statusEmoji} *Order ${actionText}*\n\n` +
                `*Order ID:* #${order.id}\n` +
                `*Customer:* ${order.customerName}\n` +
                `*Telegram:* @${order.telegramUsername}\n` +
                `*Product:* ${order.productName}\n` +
                `*Quantity:* ${order.quantity}g\n` +
                `*Total:* $${order.totalPrice}\n\n` +
                `*Action:* ${actionText} by ${adminUsername}\n` +
                `*Time:* ${new Date().toLocaleString()}`,
              parse_mode: "Markdown",
            }),
          }
        );
      }

      return res.status(200).json({ ok: true });
    }

    res.status(200).json({ ok: true });
  } catch (error) {
    console.error("[Telegram Webhook] Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

