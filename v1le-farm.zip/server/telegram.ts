import { Order } from "../drizzle/schema";

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_ADMIN_CHAT_ID = process.env.TELEGRAM_ADMIN_CHAT_ID;
const TELEGRAM_GROUP_CHAT_ID = process.env.TELEGRAM_GROUP_CHAT_ID;

interface TelegramMessage {
  chat_id: string | number;
  text: string;
  parse_mode?: string;
  reply_markup?: {
    inline_keyboard: Array<Array<{ text: string; callback_data: string }>>;
  };
}

async function sendTelegramMessage(message: TelegramMessage): Promise<boolean> {
  if (!TELEGRAM_BOT_TOKEN) {
    console.error("[Telegram] Bot token not configured");
    return false;
  }

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(message),
      }
    );

    const result = await response.json();
    return result.ok;
  } catch (error) {
    console.error("[Telegram] Failed to send message:", error);
    return false;
  }
}

export async function notifyNewOrder(order: Order): Promise<boolean> {
  const messageText = `🌿 *New Order from V1LE Farm*\n\n` +
    `*Order ID:* #${order.id}\n` +
    `*Customer:* ${order.customerName}\n` +
    `*Telegram:* @${order.telegramUsername}\n` +
    `*Product:* ${order.productName}\n` +
    `*Quantity:* ${order.quantity}g\n` +
    `*Price:* $${order.pricePerGram}/g\n` +
    `*Total:* $${order.totalPrice}\n` +
    `*Status:* ${order.status}\n` +
    `*Time:* ${order.createdAt?.toLocaleString() || "N/A"}`;

  const message: TelegramMessage = {
    chat_id: "",
    text: messageText,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "✅ Approve", callback_data: `approve_${order.id}` },
          { text: "❌ Reject", callback_data: `reject_${order.id}` },
        ],
      ],
    },
  };

  let success = true;

  // Send to admin chat
  if (TELEGRAM_ADMIN_CHAT_ID) {
    message.chat_id = TELEGRAM_ADMIN_CHAT_ID;
    const adminResult = await sendTelegramMessage(message);
    success = success && adminResult;
  }

  // Send to group chat
  if (TELEGRAM_GROUP_CHAT_ID) {
    message.chat_id = TELEGRAM_GROUP_CHAT_ID;
    const groupResult = await sendTelegramMessage(message);
    success = success && groupResult;
  }

  return success;
}

export async function notifyOrderCancelled(order: Order): Promise<boolean> {
  const messageText = `🚫 *Order Cancelled by Customer*\n\n` +
    `*Order ID:* #${order.id}\n` +
    `*Customer:* ${order.customerName} (@${order.telegramUsername})\n` +
    `*Product:* ${order.productName}\n` +
    `*Quantity:* ${order.quantity}g\n` +
    `*Total:* $${order.totalPrice}\n\n` +
    `⚠️ Customer cancelled this order request.`;

  const message: TelegramMessage = {
    chat_id: "",
    text: messageText,
    parse_mode: "Markdown",
  };

  let success = true;

  if (TELEGRAM_ADMIN_CHAT_ID) {
    message.chat_id = TELEGRAM_ADMIN_CHAT_ID;
    const adminResult = await sendTelegramMessage(message);
    success = success && adminResult;
  }

  if (TELEGRAM_GROUP_CHAT_ID) {
    message.chat_id = TELEGRAM_GROUP_CHAT_ID;
    const groupResult = await sendTelegramMessage(message);
    success = success && groupResult;
  }

  return success;
}

export async function notifyOrderDeleted(order: Order): Promise<boolean> {
  const messageText = `🗑️ *Order Removed from History*\n\n` +
    `*Order ID:* #${order.id}\n` +
    `*Customer:* ${order.customerName} (@${order.telegramUsername})\n` +
    `*Product:* ${order.productName} (${order.quantity}g)\n` +
    `*Status:* ${order.status}\n\n` +
    `ℹ️ Customer removed this order from their history.`;

  const message: TelegramMessage = {
    chat_id: "",
    text: messageText,
    parse_mode: "Markdown",
  };

  let success = true;

  if (TELEGRAM_ADMIN_CHAT_ID) {
    message.chat_id = TELEGRAM_ADMIN_CHAT_ID;
    const adminResult = await sendTelegramMessage(message);
    success = success && adminResult;
  }

  if (TELEGRAM_GROUP_CHAT_ID) {
    message.chat_id = TELEGRAM_GROUP_CHAT_ID;
    const groupResult = await sendTelegramMessage(message);
    success = success && groupResult;
  }

  return success;
}

export async function notifyOrderStatusUpdate(
  order: Order,
  newStatus: string
): Promise<boolean> {
  const messageText = `📦 *Order Status Updated*\n\n` +
    `*Order ID:* #${order.id}\n` +
    `*Customer:* @${order.telegramUsername}\n` +
    `*New Status:* ${newStatus}\n` +
    `*Product:* ${order.productName} (${order.quantity}g)`;

  const message: TelegramMessage = {
    chat_id: "",
    text: messageText,
    parse_mode: "Markdown",
  };

  let success = true;

  if (TELEGRAM_ADMIN_CHAT_ID) {
    message.chat_id = TELEGRAM_ADMIN_CHAT_ID;
    const adminResult = await sendTelegramMessage(message);
    success = success && adminResult;
  }

  if (TELEGRAM_GROUP_CHAT_ID) {
    message.chat_id = TELEGRAM_GROUP_CHAT_ID;
    const groupResult = await sendTelegramMessage(message);
    success = success && groupResult;
  }

  return success;
}

// Webhook handler for Telegram bot callbacks
export async function handleTelegramCallback(
  callbackData: string,
  updateOrderStatus: (orderId: number, status: string) => Promise<void>
): Promise<void> {
  const [action, orderIdStr] = callbackData.split("_");
  const orderId = parseInt(orderIdStr, 10);

  if (action === "approve") {
    await updateOrderStatus(orderId, "approved");
  } else if (action === "reject") {
    await updateOrderStatus(orderId, "rejected");
  }
}

