import { storagePut } from "./storage";

export async function uploadProfilePicture(base64Image: string, userId: string): Promise<string> {
  try {
    // Extract the base64 data and convert to buffer
    const matches = base64Image.match(/^data:image\/([a-zA-Z+]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      throw new Error("Invalid base64 image format");
    }

    const imageType = matches[1];
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, "base64");

    // Upload to S3
    const timestamp = Date.now();
    const key = `profile-pictures/${userId}-${timestamp}.${imageType}`;
    const result = await storagePut(key, buffer, `image/${imageType}`);

    return result.url;
  } catch (error) {
    console.error("[ProfilePicture] Failed to upload:", error);
    throw error;
  }
}

