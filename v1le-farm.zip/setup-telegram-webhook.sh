#!/bin/bash

# Telegram Bot Webhook Setup Script
# This script configures the Telegram bot to send updates to your webhook

BOT_TOKEN="${TELEGRAM_BOT_TOKEN}"
WEBHOOK_URL="https://3000-i4lx60p5qzqo9cf53uio0-6b0a1cbc.manus.computer/api/webhook/telegram"

if [ -z "$BOT_TOKEN" ]; then
  echo "Error: TELEGRAM_BOT_TOKEN environment variable is not set"
  exit 1
fi

echo "Setting up Telegram webhook..."
echo "Bot Token: ${BOT_TOKEN:0:10}..."
echo "Webhook URL: $WEBHOOK_URL"

# Set the webhook
RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setWebhook" \
  -H "Content-Type: application/json" \
  -d "{\"url\": \"${WEBHOOK_URL}\"}")

echo ""
echo "Response from Telegram:"
echo "$RESPONSE" | python3 -m json.tool

# Check webhook info
echo ""
echo "Current webhook info:"
curl -s "https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo" | python3 -m json.tool

